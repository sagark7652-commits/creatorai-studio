import Sidebar from "@/components/layout/Sidebar";
import SessionHydrator from "@/components/layout/SessionHydrator";
import CreateOrgGate from "@/components/onboarding/CreateOrgGate";
import { createClient } from "@/lib/supabase/server";
import { getUserOrgs } from "@/lib/supabase/organizations";
import type { Profile, Organization, OrgMemberRole } from "@/types/database";

interface SessionData {
  profile: Profile | null;
  org: Organization | null;
  role: OrgMemberRole | null;
  needsOrg: boolean;
}

async function getSessionData(): Promise<SessionData> {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
  if (!supabaseUrl.startsWith("http")) {
    return { profile: null, org: null, role: null, needsOrg: false };
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return { profile: null, org: null, role: null, needsOrg: false };
  }

  const [{ data: profile }, orgs] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).single(),
    getUserOrgs(supabase, user.id),
  ]);

  const org = orgs[0] ?? null;
  let role: OrgMemberRole | null = null;
  if (org) {
    const { data: member } = await supabase
      .from("org_members")
      .select("role")
      .eq("org_id", org.id)
      .eq("user_id", user.id)
      .single();
    role = member?.role ?? null;
  }

  return { profile, org, role, needsOrg: orgs.length === 0 };
}

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { profile, org, role, needsOrg } = await getSessionData();

  if (needsOrg) {
    return <CreateOrgGate />;
  }

  return (
    <div className="flex min-h-screen">
      <SessionHydrator profile={profile} org={org} role={role} />
      <Sidebar />
      <main className="flex-1 ml-60 min-h-screen overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
